#!/bin/bash

#  Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved

docker pull arxivvanity/engrafo:b3db888fefa118eacf4f13566204b68ce100b3a6
